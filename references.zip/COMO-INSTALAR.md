# Loja e biblioteca em HTML dentro do NextVR

As duas telas que você aprovou viram o **conteúdo de duas janelas** do NextVR, sem reescrever nada
em Compose e sem tocar no modo Google Cardboard, no rastreamento de mãos nem no 6DoF.

## Arquivos

| Arquivo gerado | Onde colocar no repositório |
| --- | --- |
| `app/src/main/assets/ui/store.html` | mesmo caminho |
| `app/src/main/assets/ui/library.html` | mesmo caminho |
| `app/src/main/java/com/samrat/cardboardhands/WebUiContent.kt` | mesmo caminho |

`index.html` (na raiz) é só a pré-visualização para abrir no navegador; não vai para o app.

## Como funciona

`WebUiContent` herda de `ComposeContent`, que o app já usa para desenhar janelas numa tela virtual.
Dentro dele entra um `WebView` via `AndroidView`, igual à janela do navegador. Assim:

- a janela, a barra, o arrastar, o minimizar e o toque com a mão continuam os mesmos;
- o HTML roda local, de `file:///android_asset/ui/`;
- a página conversa com o app pelo objeto `window.NextVR`.

Os dados são **reais**, não inventados:

- **Biblioteca** — lista os apps com atalho no celular (o mesmo `queryIntentActivities` do
  `AndroidAppsContent`) e os jogos VR do `GameLibrary.scan`. Os ícones vêm do próprio Android, por
  `https://nextvr.icon/<pacote>`, interceptado no Kotlin. Os ladrilhos coloridos do print
  (Netflix, TikTok, Instagram…) **só aparecem para apps que não estão instalados**, e nesse caso
  abrem a loja em vez de fingir que abrem o app.
- **Loja** — os três modos VR (Minecraft, Roblox, Brawl Stars) com os mesmos textos e cenas do
  `StoreContent`, mais os jogos do `GameStore`, com a porcentagem do download empurrada para a
  página durante a baixa.

## Ligando as janelas (em `VrHomeActivity`)

A **biblioteca** aqui é a janela "Android apps" (`AndroidAppsContent`), que é a janelinha "Apps" do
seu print. Troque onde ela é criada:

```kotlin
// antes:  AndroidAppsContent(this) { pkg, label -> ... }
LibraryWebContent(this, object : LibraryWebContent.Host {
    override fun openApp(packageName: String, label: String) = openShizukuApp(packageName, label)
    override fun playGame(packageName: String) = launchGame(packageName)
    override fun openStore() = openEntry(HomePanel.Entry(ID_STORE, tr("Store"), null))
    override fun message(text: String) = toast(text)
})
```

E a **loja**, onde hoje nasce o `StoreContent`:

```kotlin
StoreWebContent(this, object : StoreWebContent.Host {
    override fun openCinema(packageName: String, scene: String) = openCinema(packageName, scene)
    override fun install(file: File) = installApk(file)
    override fun openLibrary() = openEntry(HomePanel.Entry(ID_ANDROID, tr("Android apps"), null))
    override fun message(text: String) = toast(text)
})
```

Os nomes `openShizukuApp`, `launchGame`, `installApk` e `toast` são os que a sua `VrHomeActivity`
já usa para isso — ajuste para os que existirem no arquivo.

> O **lançador** do home (`HomePanelContent`) continua como está. Ele não é uma janela: é desenhado
> em 3D e o apontar com a mão depende das coordenadas do `HomePanel`. Trocar aquilo por HTML faria
> o ponteiro errar os alvos.

## Um ponto que você precisa corrigir à mão

Em `WebUiContent.kt`, na classe `StoreWebContent`, eu não consegui ver o **tipo** dos itens de
`GameStore.list()` no código publicado (o GitHub cortou os genéricos ao renderizar). Então deixei:

```kotlin
private var games = emptyMap<String, Any>()
```

e, no download, um `item as Nothing` que **não compila de propósito**, para não passar despercebido.
Abra `GameStore.kt`, veja o tipo real (algo como `GameStore.Item`) e troque:

1. `emptyMap<String, Any>()` → `emptyMap<String, GameStore.Item>()`
2. apague as duas linhas com `runCatching { item.javaClass.getMethod(...) }` e use direto
   `item.title` e `item.size`
3. `GameStore.download(item as Nothing, …)` → `GameStore.download(item, …)`

## Build

Não é preciso descompilar o APK. O APK do release sai do próprio `main` pelo GitHub Actions:

```
./gradlew :app:assembleFullDebug
```

## O que não foi testado

Escrevi isto lendo o código do repositório. **Não compilei, não gerei APK e não testei no celular** —
não tenho como fazer isso aqui. Espere acertos de nomes de métodos na hora de ligar as janelas, além
do ponto do `GameStore` acima.

Lembrete: o build do commit `7b890dc` (a correção do 6DoF) foi **cancelado** no Actions, então o APK
do release `latest` ainda não tem essa correção. Rode "Re-run all jobs" naquele run.
