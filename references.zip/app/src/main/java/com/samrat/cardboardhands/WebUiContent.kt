package com.samrat.cardboardhands

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.foundation.layout.fillMaxSize
import androidx.core.graphics.drawable.toBitmap
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import kotlin.concurrent.thread

/**
 * A VR window whose inside is one of NextVR's own HTML pages (`assets/ui/…`).
 *
 * It reuses [ComposeContent]'s plumbing — the private virtual display, the texture the window is
 * drawn from and the touches the fingers send — and puts a [WebView] inside it through `AndroidView`,
 * the same way the browser window shows a page. Nothing about the window chrome, the pointer or the
 * Cardboard renderer changes: only what is painted inside this one window.
 *
 * The page talks to the app through the `NextVR` object (see [bridge]); every method is called from
 * the WebView's own thread, so anything touching the home hops back to the main thread first.
 * Opening the page in a desktop browser is still useful: `window.NextVR` is simply absent there and
 * the page falls back to its demonstration list.
 */
abstract class WebUiContent(
    private val context: Context,
    private val asset: String,
    title: String,
) : ComposeContent(barTitle = title, pixelWidth = 1600, pixelHeight = 1000) {

    /** The object the page sees as `window.NextVR`. */
    protected abstract fun bridge(): Any

    private var web: WebView? = null

    /** Runs a line of JavaScript in the page, on the main thread (the page may not be up yet). */
    fun evaluate(script: String) = web?.post { web?.evaluateJavascript(script, null) }

    /** Tells the page to read its data again — after an install, a removal or a download. */
    fun reload() = evaluate("window.nextvrReload && window.nextvrReload()")

    @SuppressLint("SetJavaScriptEnabled", "AddJavascriptInterface")
    @Composable
    override fun Content() {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { viewContext ->
                WebView(viewContext).apply {
                    web = this
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    // The page is ours and local; it must not reach the file system itself.
                    settings.allowFileAccess = false
                    settings.allowContentAccess = false
                    settings.mediaPlaybackRequiresUserGesture = true
                    setBackgroundColor(android.graphics.Color.parseColor("#2b2b2f"))
                    isVerticalScrollBarEnabled = false
                    addJavascriptInterface(bridge(), "NextVR")
                    webViewClient = object : WebViewClient() {
                        /**
                         * App icons: the page asks for `https://nextvr.icon/<package>` and gets the
                         * real launcher icon as a PNG, which keeps them out of the JSON.
                         */
                        override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                            val url = request.url
                            if (url.host != "nextvr.icon") return null
                            val packageName = url.lastPathSegment ?: return null
                            val png = iconPng(view.context, packageName) ?: return null
                            return WebResourceResponse("image/png", null, ByteArrayInputStream(png))
                        }

                        /** A link the page did not expect opens outside, never inside the window. */
                        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                            val url = request.url.toString()
                            if (url.startsWith("file:///android_asset/ui/")) return false
                            runCatching {
                                view.context.startActivity(
                                    Intent(Intent.ACTION_VIEW, request.url).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                )
                            }
                            return true
                        }
                    }
                    loadUrl("file:///android_asset/ui/$asset")
                }
            },
        )
    }

    override fun release() {
        web?.post { web?.destroy(); web = null }
        super.release()
    }

    companion object {
        /** A launcher icon as PNG bytes, at the size the page draws it. */
        private fun iconPng(context: Context, packageName: String): ByteArray? = runCatching {
            val drawable: Drawable = context.packageManager.getApplicationIcon(packageName)
            val bitmap = drawable.toBitmap(96, 96)
            ByteArrayOutputStream().use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                out.toByteArray()
            }
        }.getOrNull()

        /** The icon URL the pages use for an installed app. */
        fun iconUrl(packageName: String) = "https://nextvr.icon/$packageName"
    }
}

/**
 * The library window: the phone's own apps and the installed VR games, drawn by `ui/library.html`.
 *
 * The list is the real one — every app with a launcher entry, exactly what [AndroidAppsContent]
 * shows — so nothing invented replaces what is on the phone. The page's showcase tiles (Netflix,
 * TikTok and the rest) only appear for apps that are *not* installed, and those open the store.
 */
class LibraryWebContent(
    private val context: Context,
    private val host: Host,
) : WebUiContent(context, "library.html", tr("Apps")) {

    interface Host {
        /** Opens an installed phone app as a VR window (the Shizuku virtual display). */
        fun openApp(packageName: String, label: String)
        /** Starts an installed VR game. */
        fun playGame(packageName: String)
        /** Opens the store window, for an app the phone does not have. */
        fun openStore()
        fun message(text: String)
    }

    private val recent = ArrayList<String>()
    private var games: List<GameLibrary.Game> = emptyList()

    init {
        // Scanning APKs is slow; the page reloads itself when the list is ready.
        thread(name = "NextVR library scan") {
            games = runCatching { GameLibrary.scan(context) }.getOrDefault(emptyList())
            reload()
        }
    }

    override fun bridge(): Any = object {
        @JavascriptInterface
        fun apps(): String {
            val packages = context.packageManager
            val found = runCatching {
                packages.queryIntentActivities(
                    Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
                )
                    .map { it.activityInfo.packageName to it }
                    .distinctBy { it.first }
                    .filter { it.first != context.packageName }
                    .map { (name, info) -> name to info.loadLabel(packages).toString() }
                    .sortedBy { it.second.lowercase() }
            }.getOrDefault(emptyList())
            val array = JSONArray()
            for ((packageName, label) in found) {
                array.put(
                    JSONObject()
                        .put("id", packageName)
                        .put("name", label)
                        .put("icon", iconUrl(packageName))
                        .put("bg", "#3a3a42")
                )
            }
            return array.toString()
        }

        @JavascriptInterface
        fun games(): String {
            val array = JSONArray()
            for (game in games) {
                array.put(
                    JSONObject()
                        .put("id", game.packageName)
                        .put("name", game.label)
                        .put("sub", GameLibrary.describe(game))
                        .put("icon", iconUrl(game.packageName))
                )
            }
            return array.toString()
        }

        @JavascriptInterface
        fun recent(): String = JSONArray(recent).toString()

        @JavascriptInterface
        fun remember(id: String) {
            synchronized(recent) {
                recent.remove(id)
                recent.add(0, id)
                while (recent.size > 30) recent.removeAt(recent.lastIndex)
            }
        }

        @JavascriptInterface
        fun open(packageName: String) {
            val label = runCatching {
                context.packageManager.getApplicationInfo(packageName, 0).loadLabel(context.packageManager).toString()
            }.getOrDefault(packageName)
            host.openApp(packageName, label)
        }

        @JavascriptInterface
        fun play(packageName: String) = host.playGame(packageName)

        @JavascriptInterface
        fun store(id: String) = host.openStore()
    }
}

/**
 * The store window, drawn by `ui/store.html`.
 *
 * The three VR modes are the ones the store always had — Minecraft, Roblox and Brawl Stars in the
 * cinema — and the games below them come from [GameStore], with the download percentage pushed into
 * the page as it goes.
 */
class StoreWebContent(
    private val context: Context,
    private val host: Host,
) : WebUiContent(context, "store.html", tr("Store")) {

    interface Host {
        fun openCinema(packageName: String, scene: String)
        fun install(file: File)
        fun openLibrary()
        fun message(text: String)
    }

    private class Mode(val id: String, val name: String, val sub: String, val packageName: String, val scene: String, val bg: String, val mark: String)

    private val modes = listOf(
        Mode(
            "mode:minecraft", "Minecraft VR", "Bedrock em uma tela grande", VrHomeActivity.MINECRAFT, CinemaActivity.SCENE_ROOM,
            "linear-gradient(180deg,#6cb04a 0 30%,#7a5230 30%)", "<b style=\"font-size:26px;text-shadow:0 2px 0 #1b1b1b\">M</b>",
        ),
        Mode(
            "mode:roblox", "Roblox VR", "Roblox em uma casa de Brookhaven", "com.roblox.client", CinemaActivity.SCENE_ROBLOX,
            "linear-gradient(135deg,#d3202d,#6f0f18)",
            "<span style=\"width:28px;height:28px;background:#fff;border-radius:7px;transform:rotate(-8deg);display:grid;place-items:center\"><span style=\"width:11px;height:11px;background:#d3202d;border-radius:3px\"></span></span>",
        ),
        Mode(
            "mode:brawl", "Brawl Stars VR", "No meio da arena, em 360°", "com.supercell.brawlstars", CinemaActivity.SCENE_BRAWL,
            "linear-gradient(135deg,#ffd02e 0 50%,#1280ff 50%)", "<b style=\"font-size:30px;color:#111;text-shadow:0 1px 0 #fff\">★</b>",
        ),
    )

    /** The games the server offers, keyed by the id the page sends back. */
    private var games = emptyMap<String, Any>()
    private val busy = HashSet<String>()

    init {
        thread(name = "NextVR store list") {
            games = runCatching {
                GameStore.list().associateBy { "game:" + it.path }
            }.getOrDefault(emptyMap())
            reload()
        }
    }

    private fun installed(packageName: String) =
        runCatching { context.packageManager.getApplicationInfo(packageName, 0) }.isSuccess

    override fun bridge(): Any = object {
        @JavascriptInterface
        fun store(): String {
            val array = JSONArray()
            for (mode in modes) {
                array.put(
                    JSONObject()
                        .put("id", mode.id)
                        .put("section", "Modos VR")
                        .put("name", mode.name)
                        .put("sub", mode.sub)
                        .put("bg", mode.bg)
                        .put("mark", mode.mark)
                        .put("button", if (installed(mode.packageName)) tr("Play") else tr("Download"))
                        .apply { if (installed(mode.packageName)) put("icon", iconUrl(mode.packageName)) }
                )
            }
            for ((id, item) in games) {
                // GameStore items carry a title and a size; both are read reflectively-free through
                // the same accessors StoreContent uses.
                val title = runCatching { item.javaClass.getMethod("getTitle").invoke(item) as? String }.getOrNull() ?: continue
                val size = runCatching { (item.javaClass.getMethod("getSize").invoke(item) as? Long) ?: 0L }.getOrDefault(0L)
                array.put(
                    JSONObject()
                        .put("id", id)
                        .put("section", tr("Games"))
                        .put("name", title)
                        .put("sub", if (size > 0) Updates.formatSize(size) else "")
                        .put("button", if (id in busy) "…" else tr("Get"))
                )
            }
            return array.toString()
        }

        @JavascriptInterface
        fun action(id: String) {
            val mode = modes.firstOrNull { it.id == id }
            if (mode != null) {
                if (installed(mode.packageName)) host.openCinema(mode.packageName, mode.scene)
                else runCatching {
                    context.startActivity(
                        Intent(Intent.ACTION_VIEW, android.net.Uri.parse("market://details?id=${mode.packageName}"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
                return
            }
            val item = games[id] ?: return
            synchronized(busy) { if (!busy.add(id)) return }
            thread(name = "NextVR store download") {
                val file = runCatching {
                    GameStore.download(item as Nothing, File(context.cacheDir, "patched/store")) { value ->
                        evaluate("window.nextvrProgress && window.nextvrProgress(${JSONObject.quote(id)}, ${(value * 100).toInt().coerceIn(0, 100)})")
                    }
                }.getOrNull()
                synchronized(busy) { busy.remove(id) }
                if (file != null) host.install(file) else host.message(tr("The download failed"))
                reload()
            }
        }

        @JavascriptInterface
        fun library() = host.openLibrary()
    }
}
